"""Blender-side asset validation; this does not execute MAXScript."""
import bpy
import bmesh
import json
import math
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

scene = bpy.context.scene
deps = bpy.context.evaluated_depsgraph_get()
seen = set()
counts = {'objects': 0, 'unique_meshes': 0, 'degenerate_triangles': 0,
          'inward_closed_meshes': [], 'unassigned_materials': [],
          'nonfinite_vertices': 0, 'singular_transforms': []}
minimum = Vector((1e9, 1e9, 1e9))
maximum = Vector((-1e9, -1e9, -1e9))
uv_min = [1., 1.]
uv_max = [0., 0.]
for obj in scene.objects:
    if obj.type not in {'MESH', 'CURVE'}:
        continue
    counts['objects'] += 1
    if not obj.material_slots or not obj.material_slots[0].material:
        counts['unassigned_materials'].append(obj.name)
    if obj.matrix_world.determinant() <= 0:
        counts['singular_transforms'].append(obj.name)
    ev = obj.evaluated_get(deps)
    mesh = ev.to_mesh()
    if obj.users_collection[0].name not in {'NY_ENVIRONMENT'}:
        for local in obj.bound_box:
            p = obj.matrix_world @ Vector(local)
            for i in range(3):
                minimum[i] = min(minimum[i], p[i])
                maximum[i] = max(maximum[i], p[i])
            uv = world_to_camera_view(scene, scene.camera, p)
            for i in range(2):
                uv_min[i] = min(uv_min[i], uv[i])
                uv_max[i] = max(uv_max[i], uv[i])
    key = obj.data.as_pointer() if obj.type == 'MESH' else obj.as_pointer()
    if key not in seen:
        seen.add(key)
        counts['unique_meshes'] += 1
        for vertex in mesh.vertices:
            if not all(math.isfinite(c) for c in vertex.co):
                counts['nonfinite_vertices'] += 1
        mesh.calc_loop_triangles()
        for tri in mesh.loop_triangles:
            a, b, c = [mesh.vertices[i].co for i in tri.vertices]
            if (b-a).cross(c-a).length < 1e-12:
                counts['degenerate_triangles'] += 1
        bm = bmesh.new()
        bm.from_mesh(mesh)
        if bm.edges and all(e.is_manifold for e in bm.edges):
            if bm.calc_volume(signed=True) < -1e-10:
                counts['inward_closed_meshes'].append(obj.name)
        bm.free()
    ev.to_mesh_clear()

counts['core_bounds_m'] = {'min': list(minimum), 'max': list(maximum)}
counts['core_camera_frame_fraction'] = {'min': uv_min, 'max': uv_max}
counts['external_image_paths'] = [i.filepath for i in bpy.data.images
                                  if i.source == 'FILE' and i.filepath]
counts['camera_present'] = bool(scene.camera)
counts['light_count'] = sum(o.type == 'LIGHT' for o in scene.objects)
counts['checks_passed'] = not any([
    counts['degenerate_triangles'], counts['inward_closed_meshes'],
    counts['unassigned_materials'], counts['nonfinite_vertices'],
    counts['singular_transforms'], counts['external_image_paths'],
    any(v < .015 for v in uv_min), any(v > .985 for v in uv_max),
])
out = Path(bpy.data.filepath).parent / 'geometry_checks.json'
out.write_text(json.dumps(counts, indent=2), encoding='utf-8')
print('GEOMETRY_CHECKS', json.dumps(counts), flush=True)
if not counts['checks_passed']:
    raise RuntimeError('Geometry validation failed; inspect geometry_checks.json')

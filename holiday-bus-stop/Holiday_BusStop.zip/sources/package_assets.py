"""Validate the finished scene, optionally export FBX, and render a quick review."""
import bpy
import json
import runpy
from pathlib import Path

out = Path(bpy.data.filepath).parent
runpy.run_path(str(out/'check_geometry.py'))
report = {'format': 'FBX', 'exported': False}
try:
    bpy.ops.export_scene.fbx(
        filepath=str(out/'Holiday_BusStop.fbx'),
        use_selection=False, global_scale=1., apply_unit_scale=True,
        apply_scale_options='FBX_SCALE_UNITS',
        object_types={'MESH', 'CAMERA', 'LIGHT', 'OTHER'},
        use_mesh_modifiers=True, mesh_smooth_type='FACE',
        bake_anim=False, add_leaf_bones=False,
        axis_forward='-Z', axis_up='Y',
    )
    report['exported'] = True
    report['bytes'] = (out/'Holiday_BusStop.fbx').stat().st_size
except Exception as exc:
    report['error'] = str(exc)
(out/'fbx_export.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('FBX_EXPORT', json.dumps(report), flush=True)

scene=bpy.context.scene
scene.render.resolution_percentage=45
scene.cycles.samples=20
scene.cycles.use_denoising=False
scene.render.threads=4
scene.render.filepath=str(out/'preview_review.png')
bpy.ops.render.render(write_still=True)

"""Static checks for the generated MAXScript; does not run or compile 3ds Max.

Usage: python3 check_maxscript.py [NewYear_BusStop.ms] [--report PATH]
The geometry grammar checked here matches this package's exporter only.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import math
from pathlib import Path
import re
import sys


class CheckFailure(ValueError):
    pass


@dataclass(frozen=True)
class Token:
    kind: str
    text: str
    line: int


NUMBER = re.compile(r"(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?")
IDENT = re.compile(r"[A-Za-z_][A-Za-z_0-9]*")


def lex(source: str) -> tuple[list[Token], dict[int, int]]:
    """Tokenize while excluding comments; balance (), [] and {} outside strings."""
    tokens: list[Token] = []
    pairs: dict[int, int] = {}
    stack: list[int] = []
    i, line = 0, 1
    closing = {")": "(", "]": "[", "}": "{"}
    while i < len(source):
        c = source[i]
        if c.isspace() or c == "\ufeff":
            line += c == "\n"
            i += 1
            continue
        if source.startswith("--", i):
            end = source.find("\n", i)
            i = len(source) if end < 0 else end
            continue
        if source.startswith("/*", i):
            begin, depth = line, 1
            i += 2
            while i < len(source) and depth:
                if source.startswith("/*", i):
                    depth += 1
                    i += 2
                elif source.startswith("*/", i):
                    depth -= 1
                    i += 2
                else:
                    line += source[i] == "\n"
                    i += 1
            if depth:
                raise CheckFailure(f"Unclosed comment at line {begin}")
            continue
        if c == '"':
            begin, start_line = i, line
            i += 1
            while i < len(source):
                if source[i] == "\\":
                    if i + 1 >= len(source):
                        raise CheckFailure(f"Dangling string escape at line {line}")
                    line += source[i + 1] == "\n"
                    i += 2
                elif source[i] == '"':
                    i += 1
                    break
                else:
                    line += source[i] == "\n"
                    i += 1
            else:
                raise CheckFailure(f"Unclosed string at line {start_line}")
            tokens.append(Token("string", source[begin:i], start_line))
            continue
        match = NUMBER.match(source, i)
        if match:
            tokens.append(Token("number", match.group(), line))
            i = match.end()
            continue
        match = IDENT.match(source, i)
        if match:
            tokens.append(Token("identifier", match.group(), line))
            i = match.end()
            continue
        index = len(tokens)
        tokens.append(Token("symbol", c, line))
        if c in "([{":
            stack.append(index)
        elif c in closing:
            if not stack or tokens[stack[-1]].text != closing[c]:
                raise CheckFailure(f"Unmatched {c!r} at line {line}")
            start = stack.pop()
            pairs[start] = index
            pairs[index] = start
        i += 1
    if stack:
        t = tokens[stack[-1]]
        raise CheckFailure(f"Unclosed {t.text!r} at line {t.line}")
    return tokens, pairs


class Checker:
    def __init__(self, source: str):
        self.tokens, self.pairs = lex(source)
        self.text = [t.text.lower() for t in self.tokens]

    def fail(self, i: int, message: str):
        line = self.tokens[min(i, len(self.tokens) - 1)].line
        raise CheckFailure(f"Line {line}: {message}")

    def expect(self, i: int, text: str) -> int:
        if i >= len(self.tokens) or self.text[i] != text.lower():
            self.fail(i, f"Expected {text!r}")
        return i + 1

    def number(self, i: int) -> tuple[float, int]:
        sign = 1.0
        if self.text[i] in {"+", "-"}:
            sign = -1.0 if self.text[i] == "-" else 1.0
            i += 1
        if self.tokens[i].kind != "number":
            self.fail(i, "Expected numeric coordinate or index")
        value = sign * float(self.tokens[i].text)
        if not math.isfinite(value):
            self.fail(i, "Non-finite number")
        return value, i + 1

    def integer(self, i: int) -> tuple[int, int]:
        value, end = self.number(i)
        if not value.is_integer():
            self.fail(i, "Expected integer index")
        return int(value), end

    def vector(self, i: int) -> tuple[tuple[float, float, float], int]:
        i = self.expect(i, "[")
        result = []
        for axis in range(3):
            value, i = self.number(i)
            result.append(value)
            if axis < 2:
                i = self.expect(i, ",")
        i = self.expect(i, "]")
        return tuple(result), i

    def vectors(self, i: int) -> tuple[list[tuple[float, float, float]], int]:
        i = self.expect(i, "#")
        start = i
        i = self.expect(i, "(")
        end = self.pairs[start]
        result = []
        while i < end:
            value, i = self.vector(i)
            result.append(value)
            if i < end:
                i = self.expect(i, ",")
        return result, self.expect(i, ")")

    def integer_array(self, i: int) -> tuple[list[int], int]:
        i = self.expect(i, "#")
        start = i
        i = self.expect(i, "(")
        end = self.pairs[start]
        result = []
        while i < end:
            value, i = self.integer(i)
            result.append(value)
            if i < end:
                i = self.expect(i, ",")
        return result, self.expect(i, ")")

    def run(self, expected: dict | None = None) -> dict:
        material_count = sum(
            self.text[i:i + 4] == ["append", "nymats", "(", "nymaterial"]
            for i in range(len(self.text) - 3)
        )
        if not material_count:
            raise CheckFailure("No material declarations found")
        vertices = faces = meshes = instances = appends = transforms = 0
        hard_face_count = 0
        prototypes: set[int] = set()
        pending_mesh = False
        for i in range(len(self.text)):
            if self.text[i:i + 3] == ["nyob", "=", "nymake"]:
                if pending_mesh:
                    self.fail(i, "Previous unique mesh has no prototype assignment")
                j = i + 3
                if self.tokens[j].kind != "string":
                    self.fail(j, "Missing mesh name")
                vs, j = self.vectors(j + 1)
                fs, j = self.vectors(j)
                if not vs or not fs:
                    self.fail(i, "Empty mesh")
                for face in fs:
                    if any(not index.is_integer() or not 1 <= index <= len(vs) for index in face):
                        self.fail(i, f"Face index outside 1..{len(vs)}: {face}")
                    if len(set(face)) != 3:
                        self.fail(i, f"Repeated vertex in triangle: {face}")
                j = self.expect(j, "nymats")
                j = self.expect(j, "[")
                material, j = self.integer(j)
                j = self.expect(j, "]")
                if not 1 <= material <= material_count:
                    self.fail(j, "Mesh material index is invalid")
                if self.text[j] not in {"true", "false"}:
                    self.fail(j, "Missing explicit smoothing boolean")
                j += 1
                if self.text[j] == "#":
                    hard_faces, j = self.integer_array(j)
                    if any(not 1 <= f <= len(fs) for f in hard_faces):
                        self.fail(j, "Hard-face index outside mesh face bounds")
                    hard_face_count += len(hard_faces)
                self.expect(j, "nyunit")
                meshes += 1
                vertices += len(vs)
                faces += len(fs)
                pending_mesh = True
            elif self.text[i:i + 4] == ["nyob", "=", "instance", "nyprototypes"]:
                j = self.expect(i + 4, "[")
                index, j = self.integer(j)
                self.expect(j, "]")
                if index not in prototypes:
                    self.fail(i, f"Instance uses undefined prototype {index}")
                instances += 1
            elif self.text[i] == "nyprototypes" and self.text[i + 1:i + 2] == ["["]:
                j = i + 2
                index, j = self.integer(j)
                j = self.expect(j, "]")
                if self.text[j:j + 2] == ["=", "nyob"]:
                    if index < 1 or index in prototypes or not pending_mesh:
                        self.fail(i, "Invalid or repeated prototype assignment")
                    prototypes.add(index)
                    pending_mesh = False
            if self.text[i:i + 3] == ["append", "nymade", "nyob"]:
                appends += 1
            if self.text[i:i + 5] == ["nyob", ".", "transform", "=", "matrix3"]:
                transforms += 1
                j = i + 5
                basis = []
                for _ in range(3):
                    row, j = self.vector(j)
                    basis.append(row)
                a, b, c = basis
                determinant = (a[0] * (b[1]*c[2]-b[2]*c[1])
                               - a[1] * (b[0]*c[2]-b[2]*c[0])
                               + a[2] * (b[0]*c[1]-b[1]*c[0]))
                if not math.isfinite(determinant) or determinant == 0:
                    self.fail(i, "Singular/non-finite mesh transform")
                j = self.expect(j, "(")
                _, j = self.vector(j)
                j = self.expect(j, "*")
                j = self.expect(j, "nyunit")
                self.expect(j, ")")
            if self.text[i] == "nymats" and self.text[i + 1:i + 2] == ["["]:
                index, _ = self.integer(i + 2)
                if not 1 <= index <= material_count:
                    self.fail(i, "Material reference outside declared material range")
        if pending_mesh:
            raise CheckFailure("Last unique mesh has no prototype assignment")
        if prototypes != set(range(1, meshes + 1)):
            raise CheckFailure("Prototype IDs are not contiguous 1-based mesh IDs")
        geometry_count = meshes + instances
        if appends != geometry_count or transforms != geometry_count:
            raise CheckFailure("Geometry creation/append/transform counts disagree")
        observed = {
            "objects": geometry_count,
            "unique_meshes": meshes,
            "unique_vertices": vertices,
            "unique_triangles": faces,
            "materials": material_count,
        }
        if expected:
            for key, value in observed.items():
                if key in expected and value != expected[key]:
                    raise CheckFailure(f"{key}: observed {value}, expected {expected[key]}")
        return {
            "status": "passed",
            "check_type": "static; not 3ds Max compilation or execution",
            "lexically_balanced_delimiters": True,
            "finite_vertices_and_transforms": True,
            "valid_1_based_face_indices": True,
            "prototype_before_instance": True,
            "valid_material_indices": True,
            **observed,
            "instances": instances,
            "authored_hard_faces": hard_face_count,
            "max_runtime_tested": False,
        }


def main() -> int:
    default_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("script", nargs="?", type=Path, default=default_dir / "NewYear_BusStop.ms")
    parser.add_argument("--report", type=Path)
    parser.add_argument("--without-metadata", action="store_true")
    args = parser.parse_args()
    metadata_file = args.script.parent / "validation.json"
    expected = json.loads(metadata_file.read_text()) if metadata_file.exists() and not args.without_metadata else None
    try:
        report = Checker(args.script.read_text(encoding="utf-8-sig")).run(expected)
    except (CheckFailure, IndexError, UnicodeError) as exc:
        print(f"STATIC CHECK FAILED: {exc}", file=sys.stderr)
        return 1
    report["script"] = args.script.name
    if args.report:
        args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())

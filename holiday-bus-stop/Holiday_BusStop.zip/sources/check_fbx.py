"""Export/import round-trip check in Blender, not a 3ds Max import test."""
import bpy
import json
from pathlib import Path
from mathutils import Vector

out=Path(bpy.data.filepath).parent

def snapshot():
    result={}
    deps=bpy.context.evaluated_depsgraph_get()
    for ob in bpy.context.scene.objects:
        if ob.type not in {'MESH','CURVE'}:
            continue
        ev=ob.evaluated_get(deps)
        mesh=ev.to_mesh()
        lo=[1e20]*3
        hi=[-1e20]*3
        for v in mesh.vertices:
            p=ob.matrix_world @ v.co
            for k in range(3):
                lo[k]=min(lo[k],p[k])
                hi[k]=max(hi[k],p[k])
        result[ob.name]={'bounds':lo+hi,'material':ob.material_slots[0].material.name}
        ev.to_mesh_clear()
    return result

before=snapshot()
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=str(out/'Holiday_BusStop.fbx'))
after=snapshot()
missing=sorted(set(before)-set(after))
extra=sorted(set(after)-set(before))
deviations=[]
for name in sorted(set(before)&set(after)):
    distance=max(abs(a-b) for a,b in zip(before[name]['bounds'],after[name]['bounds']))
    if distance>0.0001:
        deviations.append({'name':name,'max_bounds_error_m':distance})
report={'check_type':'FBX round-trip in Blender; not tested in 3ds Max',
        'before_objects':len(before),'after_objects':len(after),
        'missing':missing,'extra':extra,'geometry_deviations':deviations,
        'checks_passed':not any([missing,extra,deviations])}
(out/'fbx_checks.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('FBX_CHECKS',json.dumps(report),flush=True)
if not report['checks_passed']:
    raise RuntimeError('FBX round-trip mismatch')

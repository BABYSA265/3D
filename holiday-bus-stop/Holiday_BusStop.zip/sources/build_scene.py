"""Build the actual deliverable geometry, render it, and export self-contained MAXScript.

Run: blender -b --python build_scene.py
The preview and MAXScript use the same triangle meshes, not an AI image.
"""
import bpy
import math
import random
import json
import os
from mathutils import Vector, Matrix
from pathlib import Path

OUT = Path(__file__).resolve().parent
random.seed(2027)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for data in list(bpy.data.materials):
    bpy.data.materials.remove(data)

MATS = {}
META = {}
CACHE = {}
COLLS = {}
CURRENT = 'SHELTER'

def linear(c):
    return c / 12.92 if c <= .04045 else ((c + .055) / 1.055) ** 2.4

def mat(name, rgb, rough=.4, metal=0., transmission=0., emission=0.):
    srgb = tuple(v / 255 for v in rgb)
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*srgb, 1.)
    m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*[linear(v) for v in srgb], 1.)
    p.inputs['Roughness'].default_value = rough
    p.inputs['Metallic'].default_value = metal
    p.inputs['Transmission Weight'].default_value = transmission
    p.inputs['IOR'].default_value = 1.46
    if emission:
        p.inputs['Emission Color'].default_value = (*[linear(v) for v in srgb], 1.)
        p.inputs['Emission Strength'].default_value = emission
    MATS[name] = m
    META[name] = dict(rgb=rgb, rough=rough, metal=metal,
                      transmission=transmission, emission=emission)
    return m

mat('Bronze_Frame', (43, 49, 49), .27, .78)
mat('Champagne_Gold', (219, 173, 86), .25, .8)
mat('Bright_Gold', (244, 199, 112), .23, .7)
mat('Burgundy', (100, 12, 30), .34)
mat('Santa_Red', (166, 18, 33), .46)
mat('Hat_Red', (191, 24, 40), .5)
mat('Red_Ornaments', (171, 19, 31), .18, .5)
mat('Fur_Ivory', (249, 242, 218), .88)
mat('Fur_Shadow', (222, 220, 207), .9)
mat('Snow', (235, 244, 251), .72)
mat('Pine_Dark', (12, 41, 29), .68)
mat('Pine_Mid', (29, 66, 41), .61)
mat('Pine_Tips', (62, 91, 52), .63)
mat('Leather', (24, 21, 24), .3)
mat('Soles', (10, 12, 15), .58)
mat('Skin', (231, 169, 133), .6)
mat('Cheeks', (206, 112, 102), .63)
mat('Eye', (22, 32, 35), .16)
mat('White', (255, 252, 234), .35)
mat('Bench_Wood', (118, 67, 39), .36)
mat('Glass', (207, 231, 232), .045, transmission=1.)
mat('Gift_Cream', (231, 215, 180), .38)
mat('Gift_Green', (22, 74, 54), .4)
mat('Gift_Red', (131, 15, 36), .34)
mat('Gift_Paper_Gold', (191, 139, 54), .37, .22)
mat('Ribbon', (238, 189, 100), .27, .42)
mat('Paving_1', (103, 117, 127), .28)
mat('Paving_2', (116, 128, 137), .31)
mat('Paving_3', (89, 104, 115), .24)
mat('Ground', (160, 177, 190), .72)
mat('Warm_LED', (255, 201, 112), .3, emission=5.)
mat('Panel_LED', (255, 208, 132), .3, emission=2.)

def collection(name):
    if name not in COLLS:
        c = bpy.data.collections.new('NY_' + name)
        bpy.context.scene.collection.children.link(c)
        COLLS[name] = c
    return COLLS[name]

def register(obj, name, material=None):
    obj.name = name
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    collection(CURRENT).objects.link(obj)
    if material:
        if not obj.data.materials:
            obj.data.materials.append(MATS[material])
        obj.material_slots[0].link = 'OBJECT'
        obj.material_slots[0].material = MATS[material]
    return obj

def mesh_obj(name, verts, faces, material, smooth=False):
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.update()
    for p in mesh.polygons:
        p.use_smooth = smooth
    ob = bpy.data.objects.new(name, mesh)
    return register(ob, name, material)

def shared(name, data, loc, material, scale=(1, 1, 1)):
    ob = bpy.data.objects.new(name, data)
    ob.location = loc
    ob.scale = scale
    return register(ob, name, material)

def box(name, loc, size, material, bevel=.012, rot=0):
    key = ('box', tuple(size), bevel)
    if key not in CACHE:
        bpy.ops.mesh.primitive_cube_add(size=1)
        temp = bpy.context.object
        temp.scale = size
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        if bevel:
            mod = temp.modifiers.new('Soft manufactured edges', 'BEVEL')
            mod.width = min(bevel, min(size) * .32)
            mod.segments = 3
            bpy.ops.object.modifier_apply(modifier=mod.name)
        CACHE[key] = temp.data
        bpy.data.objects.remove(temp, do_unlink=True)
    ob = shared(name, CACHE[key], loc, material)
    ob.rotation_euler.z = rot
    return ob

def sphere(name, loc, scale, material, detail=20):
    key = ('sphere', detail)
    if key not in CACHE:
        bpy.ops.mesh.primitive_uv_sphere_add(segments=detail, ring_count=max(8, detail // 2), radius=1)
        tmp = bpy.context.object
        for p in tmp.data.polygons:
            p.use_smooth = True
        CACHE[key] = tmp.data
        bpy.data.objects.remove(tmp, do_unlink=True)
    return shared(name, CACHE[key], loc, material, scale)

def tube(name, points, radius, material, resolution=3, cyclic=False):
    curve = bpy.data.curves.new(name, 'CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 1
    curve.bevel_depth = radius
    curve.bevel_resolution = resolution
    curve.resolution_u = 1
    spline = curve.splines.new('POLY')
    spline.points.add(len(points) - 1)
    for p, co in zip(spline.points, points):
        p.co = (*co, 1.)
    spline.use_cyclic_u = cyclic
    ob = bpy.data.objects.new(name, curve)
    return register(ob, name, material)

def cylinder_between(name, a, b, radius, material, radius2=None, segments=20):
    a, b = Vector(a), Vector(b)
    length = (b - a).length
    key = ('cylinder', radius, radius2, length, segments)
    if key not in CACHE:
        bpy.ops.mesh.primitive_cone_add(vertices=segments, radius1=radius,
            radius2=radius if radius2 is None else radius2, depth=length)
        tmp = bpy.context.object
        for p in tmp.data.polygons:
            p.use_smooth = len(p.vertices) == 4
        CACHE[key] = tmp.data
        bpy.data.objects.remove(tmp, do_unlink=True)
    ob = shared(name, CACHE[key], (a + b) / 2, material)
    ob.rotation_euler = (b - a).to_track_quat('Z', 'Y').to_euler()
    return ob

def limb(name, a, b, width, depth, material):
    a, b = Vector(a), Vector(b)
    ob = sphere(name, (a + b) / 2, (width, depth, (a-b).length/2 + width*.55), material, 28)
    ob.rotation_euler = (b-a).to_track_quat('Z', 'Y').to_euler()
    return ob

def ring_points(center, rx, ry, count=48, plane='XY'):
    x, y, z = center
    out = []
    for i in range(count):
        t = i * math.tau / count
        if plane == 'XZ':
            out.append((x + rx*math.cos(t), y, z + ry*math.sin(t)))
        else:
            out.append((x + rx*math.cos(t), y + ry*math.sin(t), z))
    return out

def fur_ring(name, center, rx, ry, thickness=.035, plane='XY', count=48):
    pts = ring_points(center, rx, ry, count, plane)
    tube(name + '_base', pts, thickness*.72, 'Fur_Ivory', cyclic=True)
    for i, p in enumerate(pts):
        s = thickness * random.uniform(.8, 1.22)
        sphere(name + '_tuft', p, (s, s*.9, s*1.1),
               'Fur_Ivory' if i%7 else 'Fur_Shadow', 12)

def star(name, center, radius, material, thickness=.018):
    cx, cy, cz = center
    vs=[]
    for y in (cy-thickness/2, cy+thickness/2):
        for i in range(10):
            a=math.pi/2 + i*math.pi/5
            r=radius if i%2==0 else radius*.43
            vs.append((cx+r*math.cos(a), y, cz+r*math.sin(a)))
    faces=[tuple(reversed(range(10))), tuple(range(10,20))]
    for i in range(10):
        j=(i+1)%10
        faces.append((i,j,j+10,i+10))
    return mesh_obj(name,vs,[tuple(reversed(face)) for face in faces],material)

# -- Architectural shell: dimensions in metres; front is negative Y. --
CURRENT = 'SHELTER'
for x in (-2.25, 2.25):
    for y in (-.86, .86):
        box('Bronze structural post', (x,y,1.36), (.085,.085,2.72), 'Bronze_Frame', .009)
        cylinder_between('Cast base', (x,y,.015),(x,y,.12), .105,'Bronze_Frame')
        cylinder_between('Gold base collar',(x,y,.13),(x,y,.153),.07,'Champagne_Gold')
        cylinder_between('Post collar',(x,y,.43),(x,y,.455),.055,'Champagne_Gold')
        box('Post capital',(x,y,2.65),(.145,.145,.10),'Champagne_Gold',.015)
        for dx in (-.045,.045):
            for dy in (-.045,.045):
                sphere('Anchor head',(x+dx,y+dy,.128),(.009,.009,.006),'Bright_Gold',12)

for z in (.23,2.47):
    box('Rear bronze rail',(0,.875,z),(4.5,.045,.055),'Bronze_Frame',.006)
    for x in (-2.25,2.25):
        box('Side bronze rail',(x,0,z),(.045,1.72,.055),'Bronze_Frame',.006)
for x in (-.76,.76):
    box('Rear glass mullion',(x,.88,1.35),(.035,.035,2.22),'Bronze_Frame',.004)
for x in (-1.50,0,1.50):
    box('Rear laminated glass',(x,.88,1.35),(1.435,.012,2.17),'Glass',.002)
for x in (-2.25,2.25):
    box('Side laminated glass',(x,0,1.35),(.012,1.62,2.17),'Glass',.002)
    for y in (-.68,.68):
        for z in (.38,2.29):
            sphere('Glass fixing',(x-.012,y,z),(.018,.018,.018),'Champagne_Gold',12)
    box('Side safety stripe',(x-.009,0,1.1),(.008,1.54,.018),'Champagne_Gold',.001)

box('Roof structural slab',(0,0,2.72),(4.90,2.13,.16),'Bronze_Frame',.065)
box('Roof gold reveal',(0,0,2.80),(4.94,2.17,.035),'Champagne_Gold',.015)
box('Roof snow continuous cap',(0,0,2.895),(5.02,2.23,.19),'Snow',.085)
for i in range(53):
    x=-2.43+i*.093
    for y in (-1.075,1.075):
        sphere('Soft roof snow overhang',(x,y,2.88+random.uniform(-.014,.022)),
               (random.uniform(.065,.10),.065,random.uniform(.055,.075)),'Snow',12)
for x in (-2.45,2.45):
    for i in range(20):
        sphere('Snow side edge',(x,-.98+i*.103,2.89),(.07,.085,.06),'Snow',12)

# Bench: six hardwood slats and a slightly reclined back.
for x in (-1.42,.12):
    box('Bench foot',(x,.36,.25),(.07,.52,.50),'Bronze_Frame',.012)
    box('Bench shoe',(x,.36,.035),(.30,.60,.055),'Bronze_Frame',.014)
for y in (.15,.25,.35,.45,.55):
    box('Bench seat slat',(-.65,y,.51),(2.26,.082,.052),'Bench_Wood',.013)
for z in (.80,.93,1.06):
    box('Bench back slat',(-.65,.66,z),(2.26,.054,.105),'Bench_Wood',.014)
for x in (-1.57,.27):
    tube('Bench armrest',[(x,.12,.52),(x,.12,.77),(x,.50,.77),(x,.60,.58)],.024,'Bronze_Frame')

# Central glowing artwork on the back wall; all artwork is geometry.
CURRENT='ART_PANEL'
px=1.21
box('Burgundy festive panel',(px,.825,1.39),(1.11,.066,2.24),'Burgundy',.025)
for x in (px-.54,px+.54):
    box('Gold panel vertical',(x,.782,1.39),(.025,.018,2.22),'Champagne_Gold',.006)
for z in (.285,2.495):
    box('Gold panel horizontal',(px,.782,z),(1.09,.018,.025),'Champagne_Gold',.006)
star('Golden star',(px,.757,2.20),.13,'Panel_LED')
for offset, width in ((0,1.),(.045,.84)):
    pts=[(px,.753,2.04-offset),(px-.16*width,.753,1.81-offset),
         (px-.07*width,.753,1.82-offset),(px-.30*width,.753,1.48-offset),
         (px-.16*width,.753,1.51-offset),(px-.44*width,.753,.99-offset),
         (px,.753,1.12-offset),(px+.44*width,.753,.99-offset),
         (px+.16*width,.753,1.51-offset),(px+.30*width,.753,1.48-offset),
         (px+.07*width,.753,1.82-offset),(px+.16*width,.753,1.81-offset),
         (px,.753,2.04-offset)]
    tube('Illuminated tree outline',pts,.009 if offset==0 else .0038,'Panel_LED')
for i in range(30):
    x=px+random.uniform(-.45,.45)
    z=random.uniform(.50,2.32)
    sphere('Panel starlight',(x,.747,z),(.007,.005,.007),'Bright_Gold',12)
tube('Panel ornament loop',ring_points((px,.745,.67),.11,.12,32,'XZ'),.006,'Bright_Gold',cyclic=True)
star('Panel lower ornament',(px,.742,.68),.065,'Champagne_Gold',.008)

# -- Evergreen fascia, handplaced ornaments and light scallops. --
CURRENT='GARLAND'
foliage={m:([],[]) for m in ('Pine_Dark','Pine_Mid','Pine_Tips')}
def pine_spray(center, radius=.18):
    cx,cy,cz=center
    for _ in range(20):
        a=random.uniform(0,math.tau)
        d=random.uniform(.03,radius)
        base=Vector((cx+random.uniform(-.045,.045),cy+math.cos(a)*d*.4,cz+math.sin(a)*d*.4))
        tip=base+Vector((random.uniform(-.11,.11),math.cos(a)*random.uniform(.08,.16),math.sin(a)*random.uniform(.07,.15)))
        direction=(tip-base).normalized()
        side=direction.cross(Vector((1,0,.1))).normalized()*.008
        v,f=foliage[random.choices(['Pine_Dark','Pine_Mid','Pine_Tips'],[4,4,1])[0]]
        start=len(v)
        v.extend([tuple(base-side),tuple(base+side),tuple(tip),tuple(base+Vector((0,.008,0)))])
        f.extend([(start,start+1,start+2),(start+1,start+3,start+2)])

garland_paths=[[(x,-1.12,2.72+.028*math.sin(x*3.5)) for x in [-2.45+i*.045 for i in range(110)]]]
for x in (-2.45,2.45):
    garland_paths.append([(x,-1.02+i*.045,2.72) for i in range(46)])
for pts in garland_paths:
    tube('Evergreen core',pts,.095,'Pine_Dark')
    for p in pts:
        pine_spray(p)
for material,(verts,faces) in foliage.items():
    mesh_obj('Individual pine needles '+material,verts,faces,material)
for i in range(23):
    x=-2.35+i*.212
    z=2.66+random.uniform(-.045,.025)
    radius=random.uniform(.047,.073)
    material='Red_Ornaments' if i%3==1 else 'Champagne_Gold'
    sphere('Christmas bauble',(x,-1.33,z),(radius,radius,radius),material,24)
    cylinder_between('Bauble cap',(x,-1.33,z+radius*.85),(x,-1.33,z+radius+.019),.012,'Champagne_Gold')
    tube('Bauble loop',ring_points((x,-1.33,z+radius+.028),.012,.016,12,'XZ'),.002,'Champagne_Gold',1,True)
for side in (-1,1):
    for i in range(8):
        y=-.88+i*.25
        r=random.uniform(.045,.065)
        sphere('Side Christmas bauble',(side*2.62,y,2.65),(r,r,r),
               'Red_Ornaments' if i%3==0 else 'Champagne_Gold',24)
        cylinder_between('Side bauble cap',(side*2.62,y,2.65+r*.85),
                         (side*2.62,y,2.65+r+.016),.01,'Champagne_Gold')
for j in range(7):
    left=-2.43+j*.695
    pts=[]
    for i in range(21):
        t=i/20
        pts.append((left+t*.695,-1.39,2.64-.15*math.sin(math.pi*t)))
    tube('Fine gold light cable',pts,.0025,'Champagne_Gold',1)
    for i in (2,6,10,14,18):
        x,y,z=pts[i]
        cylinder_between('Pendant bulb socket',(x,y,z),(x,y,z-.025),.008,'Champagne_Gold',segments=12)
        sphere('Warm hanging lamp',(x,y,z-.044),(.017,.017,.024),'Warm_LED',16)
for i in range(16):
    x=random.uniform(-2.4,2.4)
    cylinder_between('Roof icicle',(x,-1.11,2.83),(x,-1.11,2.83-random.uniform(.04,.13)),.010,'Snow',radius2=.001,segments=8)

# -- Presents with dimensional satin bows. --
CURRENT='GIFTS'
def gift(name, loc, size, material, angle=0):
    x,y,z=loc
    w,d,h=size
    root=Matrix.Translation(Vector(loc)) @ Matrix.Rotation(angle,4,'Z')
    created=[]
    def local_box(label,pos,dims,matname,bev=.012):
        ob=box(name+' '+label,pos,dims,matname,bev)
        created.append(ob)
        return ob
    local_box('paper',(0,0,h/2),(w,d,h),material)
    local_box('lid',(0,0,h+.012),(w+.026,d+.026,.045),material,.009)
    rw=min(w,d)*.135
    local_box('ribbon vertical',(0,0,h/2+.018),(rw,d+.008,h+.042),'Ribbon',.003)
    local_box('ribbon cross',(0,0,h/2+.018),(w+.008,rw,h+.044),'Ribbon',.003)
    # Two broad loop ribbons, modeled as strips with real width.
    for side in (-1,1):
        pts=[]
        for i in range(33):
            t=math.tau*i/32
            pts.append((side*(.04+w*.19*(1-math.cos(t))),.015*math.sin(t),h+.08+h*.15*(1+math.sin(t))))
        ob=tube(name+' satin bow loop',pts,rw*.24,'Ribbon',3)
        created.append(ob)
    created.append(sphere(name+' bow knot',(0,0,h+.065),(.055,.04,.035),'Ribbon',16))
    for ob in created:
        # matrix_world can still be stale directly after creating a datablock.
        local=Matrix.LocRotScale(ob.location.copy(),ob.rotation_euler.to_quaternion(),ob.scale.copy())
        ob.matrix_world=root @ local
    # Tiny metallic dots on wrapping, not texture maps.
    for i in range(max(4,int(w/.09))):
        for j in range(max(3,int(h/.10))):
            p=Vector((-w/2+.045+i*.09,-d/2-.004,.06+j*.1))
            if p.x < w/2-.02 and p.z < h-.02:
                center=root @ p
                dot=sphere(name+' foil dot',center,(.006,.003,.006),'Champagne_Gold',8)
                dot.rotation_euler.z=angle

gift('Large golden present',(.90,.15,3.005),(.66,.62,.70),'Gift_Paper_Gold',-.10)
gift('Tall burgundy present',(1.64,.37,3.005),(.53,.55,.94),'Gift_Red',.10)
gift('Cream present',(1.53,-.39,3.005),(.70,.55,.45),'Gift_Cream',-.06)
gift('Green present',(.48,-.46,3.005),(.40,.38,.38),'Gift_Green',.12)
gift('Small red present',(1.02,.15,3.76),(.43,.39,.35),'Gift_Red',.14)

# -- Sculptural, seated Santa. All shapes are real, editable meshes. --
CURRENT='SANTA'
sx=-1.18
sphere('Santa coat body',(sx,-.16,3.63),(.46,.35,.57),'Santa_Red',40)
sphere('Santa seated coat skirt',(sx,-.18,3.23),(.47,.37,.24),'Santa_Red',32)
fur_ring('Coat hem',(sx,-.18,3.18),.43,.32,.043,count=64)
# Belt follows the belly rather than looking like a flat floating strip.
tube('Broad leather belt',ring_points((sx,-.16,3.47),.457,.351,64),.046,'Leather',4,True)
box('Golden belt buckle',(sx,-.526,3.47),(.16,.026,.125),'Champagne_Gold',.018)
box('Buckle dark inset',(sx,-.544,3.47),(.108,.012,.078),'Leather',.006)
box('Buckle pin',(sx,-.555,3.47),(.11,.014,.014),'Champagne_Gold',.003)
for z in (3.64,3.81):
    sphere('Coat button',(sx,-.509,z),(.022,.014,.022),'Champagne_Gold',16)
for dx in (-.24,.24):
    hip=(sx+dx,-.25,3.28)
    knee=(sx+dx*1.06,-1.06,3.16)
    ankle=(sx+dx*1.09,-1.21,2.73)
    limb('Red trouser thigh',hip,knee,.175,.18,'Santa_Red')
    limb('Red trouser shin',knee,ankle,.13,.135,'Santa_Red')
    fur_ring('Boot furry cuff',(ankle[0],ankle[1],2.83),.136,.135,.032,count=30)
    sphere('Leather boot shaft',(ankle[0],-1.23,2.69),(.139,.145,.20),'Leather',28)
    sphere('Leather boot toe',(ankle[0],-1.39,2.58),(.16,.275,.115),'Leather',28)
    box('Heavy boot sole',(ankle[0],-1.39,2.505),(.31,.49,.047),'Soles',.023)
    box('Boot heel',(ankle[0],-1.22,2.48),(.23,.13,.065),'Soles',.015)

# One arm resting on lap; the other raised in a readable wave.
left_sh=(sx-.37,-.16,3.91)
left_el=(sx-.57,-.46,3.61)
left_wr=(sx-.36,-.78,3.51)
limb('Left upper sleeve',left_sh,left_el,.17,.17,'Santa_Red')
limb('Left forearm sleeve',left_el,left_wr,.135,.14,'Santa_Red')
fur_ring('Left sleeve fur',left_wr,.14,.13,.031,plane='XZ',count=30)
sphere('Resting leather mitten',(sx-.32,-.86,3.49),(.13,.13,.09),'Leather',24)
sphere('Resting mitten thumb',(sx-.20,-.83,3.50),(.055,.08,.05),'Leather',16)
right_sh=(sx+.37,-.15,3.92)
right_el=(sx+.68,-.21,4.12)
right_wr=(sx+.79,-.26,4.48)
limb('Waving upper sleeve',right_sh,right_el,.165,.17,'Santa_Red')
limb('Waving forearm sleeve',right_el,right_wr,.12,.125,'Santa_Red')
fur_ring('Waving cuff',right_wr,.12,.11,.031,count=30)
hand=sphere('Raised leather mitten',(sx+.83,-.27,4.62),(.115,.068,.17),'Leather',28)
hand.rotation_euler.y=-.20
limb('Raised mitten thumb',(sx+.76,-.29,4.56),(sx+.66,-.32,4.65),.046,.047,'Leather')
for z in (4.57,4.62,4.67):
    tube('Mitten stitching',[(sx+.78,-.335,z),(sx+.88,-.335,z+.017)],.002,'Bench_Wood',1)

# Face, ears and hair.
sphere('Santa neck',(sx,-.15,4.10),(.15,.16,.18),'Skin',28)
sphere('Santa head',(sx,-.25,4.26),(.272,.235,.305),'Skin',40)
for side in (-1,1):
    sphere('Santa ear',(sx+side*.263,-.24,4.25),(.057,.055,.088),'Skin',20)
    sphere('Santa rosy cheek',(sx+side*.151,-.443,4.20),(.071,.022,.043),'Cheeks',20)
    sphere('Santa eye white',(sx+side*.094,-.463,4.30),(.044,.016,.027),'White',20)
    sphere('Santa eye',(sx+side*.088,-.478,4.299),(.016,.009,.018),'Eye',20)
    sphere('Eye catchlight',(sx+side*.088-.004,-.486,4.306),(.004,.003,.005),'White',12)
    brow=sphere('White bushy eyebrow',(sx+side*.097,-.463,4.354),(.068,.025,.025),'Fur_Ivory',20)
    brow.rotation_euler.y=side*.15
    tube('Fine golden spectacles',ring_points((sx+side*.099,-.49,4.295),.065,.048,32,'XZ'),.004,'Champagne_Gold',2,True)
    tube('Spectacle sidearm',[(sx+side*.158,-.48,4.30),(sx+side*.245,-.30,4.31)],.003,'Champagne_Gold',1)
tube('Spectacle bridge',[(sx-.034,-.493,4.30),(sx,-.505,4.313),(sx+.034,-.493,4.30)],.004,'Champagne_Gold')
sphere('Rounded Santa nose',(sx,-.506,4.235),(.064,.068,.052),'Skin',28)
sphere('Smile behind moustache',(sx,-.460,4.111),(.068,.025,.031),'Burgundy',20)
# A continuous tapered beard, with smaller curls layered on its surface.
sphere('Beard cheek left',(sx-.175,-.398,4.13),(.090,.083,.17),'Fur_Ivory',28)
sphere('Beard cheek right',(sx+.175,-.398,4.13),(.090,.083,.17),'Fur_Ivory',28)
sphere('Full beard foundation',(sx,-.411,4.005),(.223,.125,.23),'Fur_Ivory',32)
sphere('Tapered beard point',(sx+.018,-.42,3.86),(.123,.09,.115),'Fur_Ivory',24)
for side in (-1,1):
    moustache=sphere('Swept moustache',(sx+side*.075,-.491,4.15),(.097,.042,.044),'Fur_Ivory',28)
    moustache.rotation_euler.y=side*.22
for i in range(44):
    u=random.uniform(-1,1)
    v=random.uniform(-1,1)
    if u*u+v*v>1:
        continue
    x=sx+u*.196
    z=4.005+v*.19
    y=-.437-.10*math.sqrt(max(.02,1-u*u-v*v))
    r=random.uniform(.022,.038)
    curl=sphere('Beard individual curl',(x,y,z),(r,r*.65,r*1.5),'Fur_Ivory' if i%6 else 'Fur_Shadow',16)
    curl.rotation_euler.y=random.uniform(-.5,.5)
for side in (-1,1):
    for i in range(9):
        z=4.14+i*.032
        sphere('Curly side hair',(sx+side*.25,-.20,z),(.04,.055,.045),'Fur_Ivory',16)

# Bent, tapering cloth hat with a drooping end.
hat_path=[((sx,-.23,4.49),.275),((sx-.02,-.21,4.61),.24),
          ((sx-.11,-.20,4.74),.18),((sx-.25,-.21,4.81),.115),
          ((sx-.40,-.23,4.76),.068),((sx-.46,-.25,4.66),.018)]
vs=[]
seg=40
for index,(p,r) in enumerate(hat_path):
    center=Vector(p)
    before=Vector(hat_path[max(0,index-1)][0])
    after=Vector(hat_path[min(len(hat_path)-1,index+1)][0])
    axis=(after-before).normalized()
    u=axis.cross(Vector((0,1,0))).normalized()
    v=axis.cross(u).normalized()
    for k in range(seg):
        a=math.tau*k/seg
        wrinkle=1+.025*math.sin(k*3+index)
        vs.append(tuple(center+r*wrinkle*(math.cos(a)*u+math.sin(a)*v)))
fs=[]
for j in range(len(hat_path)-1):
    for i in range(seg):
        fs.append((j*seg+i,j*seg+(i+1)%seg,(j+1)*seg+(i+1)%seg,(j+1)*seg+i))
fs.extend([tuple(reversed(range(seg))),tuple((len(hat_path)-1)*seg+i for i in range(seg))])
mesh_obj('Bent red Santa hat',vs,fs,'Hat_Red',True)
fur_ring('Hat thick fur brim',(sx,-.23,4.49),.278,.253,.045,count=56)
pom=(sx-.47,-.25,4.63)
sphere('Hat pompom',pom,(.103,.101,.113),'Fur_Ivory',24)
for _ in range(28):
    d=Vector((random.uniform(-1,1),random.uniform(-1,1),random.uniform(-1,1))).normalized()
    p=Vector(pom)+d*.089
    sphere('Pompom tuft',p,(.021,.021,.024),'Fur_Ivory',12)

# A cloth gift sack and its gathered neck, tucked behind Santa.
sphere('Santa burgundy sack',(sx-.64,.19,3.37),(.38,.34,.40),'Burgundy',32)
limb('Gathered sack neck',(sx-.63,.16,3.65),(sx-.52,.13,3.85),.15,.12,'Burgundy')
tube('Sack gold drawstring',ring_points((sx-.56,.14,3.76),.14,.105,36),.013,'Champagne_Gold',3,True)
for j in range(7):
    theta=math.tau*j/7
    points=[]
    for k in range(11):
        t=k/10
        points.append((sx-.64+(.33-.18*t)*math.cos(theta),
                       .19+(.27-.13*t)*math.sin(theta),3.18+.56*t))
    tube('Sack cloth seam',points,.005,'Santa_Red',2)

# -- Winter paving and restrained background. --
CURRENT='ENVIRONMENT'
box('Winter plaza foundation',(0,0,-.13),(200,200,.18),'Ground',.015)
for ix in range(-8,9):
    for iy in range(-7,8):
        x=ix*.78+(.39 if iy%2 else 0)
        y=iy*.52
        box('Wet stone paving',(x,y,-.025),(.765,.505,.07),
            random.choice(['Paving_1','Paving_1','Paving_2','Paving_3']),.009)
for x in (-2.25,2.25):
    for y in (-.86,.86):
        sphere('Snow piled at base',(x,y,.025),(.22,.23,.065),'Snow',20)
for i in range(55):
    angle=random.uniform(0,math.tau)
    distance=random.uniform(3.0,7.0)
    x=math.cos(angle)*distance
    y=math.sin(angle)*distance
    if y < -2.2 and abs(x)<2.2:
        continue
    sphere('Thawing snow bank',(x,y,.027),
        (random.uniform(.18,.58),random.uniform(.14,.43),random.uniform(.018,.055)),'Snow',16)

def winter_tree(x,y,height):
    cylinder_between('Fir trunk',(x,y,0),(x,y,height*.76),.09,'Bench_Wood')
    for k in range(7):
        z=.35+k*height*.105
        r=height*.27*(1-k*.12)
        cylinder_between('Fir tier',(x,y,z),(x,y,z+height*.35),r,'Pine_Dark',radius2=0.,segments=32)
        cylinder_between('Fir snowy tier',(x,y,z+.08),(x,y,z+height*.35+.06),r*.98,'Snow',radius2=0.,segments=32)
for args in [(-4.7,3.4,3.8),(4.7,4.1,4.3),(1.8,6.2,3.5),(-1.7,6.8,4.0)]:
    winter_tree(*args)

def lamp(x,y):
    cylinder_between('Streetlamp pole',(x,y,0),(x,y,3.9),.048,'Bronze_Frame')
    cylinder_between('Streetlamp foot',(x,y,0),(x,y,.20),.13,'Bronze_Frame')
    cylinder_between('Streetlamp gold collar',(x,y,3.75),(x,y,3.80),.066,'Champagne_Gold')
    for side in (-1,1):
        pts=[]
        for k in range(25):
            t=k/24
            pts.append((x+side*.5*t,y,3.8+.24*math.sin(math.pi*t)))
        tube('Streetlamp curved arm',pts,.026,'Bronze_Frame')
        xx=x+side*.5
        box('Lantern warm diffuser',(xx,y,3.55),(.17,.17,.30),'Warm_LED',.03)
        for dx in (-.10,.10):
            for dy in (-.10,.10):
                cylinder_between('Lantern mullion',(xx+dx,y+dy,3.36),(xx+dx,y+dy,3.74),.012,'Bronze_Frame',segments=10)
        box('Lantern floor',(xx,y,3.36),(.24,.24,.035),'Bronze_Frame',.01)
        cylinder_between('Lantern roof',(xx,y,3.75),(xx,y,3.88),.18,'Bronze_Frame',radius2=.015,segments=4)
        cylinder_between('Lantern snow',(xx,y,3.77),(xx,y,3.90),.165,'Snow',radius2=.012,segments=4)
lamp(-3.45,2.2)
lamp(3.5,2.7)

# Camera and soft winter illumination.
CURRENT='LIGHTS'
def area(name,loc,target,power,size,color):
    data=bpy.data.lights.new(name,'AREA')
    data.energy=power
    data.shape='DISK'
    data.size=size
    data.color=color
    ob=bpy.data.objects.new(name,data)
    collection(CURRENT).objects.link(ob)
    ob.location=loc
    ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler()
    return ob
area('Warm winter key',(-4,-6,9),(0,0,2.3),1600,6,(1.,.88,.74))
area('Cool sky fill',(5,-2,7),(0,0,2.3),1100,6,(.66,.80,1.))
area('High rim',(0,5,8),(0,0,2.4),1900,5,(.86,.91,1.))
area('Front face bounce',(-1,-5,4),(sx,-.3,4.2),110,3,(1.,.78,.57))
for x in (-1.5,0,1.5):
    area('Warm fascia bounce',(x,-1.12,2.57),(x,-.5,1.7),7,.45,(1.,.58,.23))
world=bpy.data.worlds.new('Cool winter sky')
world.use_nodes=True
world.node_tree.nodes['Background'].inputs[0].default_value=(.36,.46,.59,1)
world.node_tree.nodes['Background'].inputs[1].default_value=.45
bpy.context.scene.world=world

camdata=bpy.data.cameras.new('NY_Hero_Camera')
camera=bpy.data.objects.new('NY_Hero_Camera',camdata)
collection('CAMERAS').objects.link(camera)
camera.location=(-7.0,-10.5,5.7)
aim=Vector((0,-.05,2.18))
camera.rotation_euler=(aim-camera.location).to_track_quat('-Z','Y').to_euler()
camdata.lens=60
camdata.sensor_width=36
camdata.clip_start=.03
camdata.clip_end=200
bpy.context.scene.camera=camera

# -- Export exact evaluated mesh geometry to a standalone .ms. --
def fmt(v):
    if abs(v)<.0000005:
        return '0.0'
    s=f'{v:.6f}'.rstrip('0').rstrip('.')
    return s if '.' in s else s+'.0'

def point(p):
    return '['+','.join(fmt(v) for v in p)+']'

def msquote(s):
    return json.dumps(s,ensure_ascii=True)

def export_maxscript():
    deps=bpy.context.evaluated_depsgraph_get()
    path=OUT/'NewYear_BusStop.ms'
    all_objects=sorted((o for o in bpy.context.scene.objects if o.type in {'MESH','CURVE'}),key=lambda o:o.name)
    mesh_ids={}
    mesh_defs=[]
    instances=[]
    face_count=0
    vertex_count=0
    for ob in all_objects:
        key=('mesh',ob.data.as_pointer()) if ob.type=='MESH' and not ob.modifiers else ('eval',ob.as_pointer())
        if key not in mesh_ids:
            ev=ob.evaluated_get(deps)
            me=ev.to_mesh()
            me.calc_loop_triangles()
            verts=[tuple(v.co) for v in me.vertices]
            faces=[tuple(i+1 for i in t.vertices) for t in me.loop_triangles]
            smooth=any(p.use_smooth for p in me.polygons)
            hard_faces=[i+1 for i,t in enumerate(me.loop_triangles)
                        if not me.polygons[t.polygon_index].use_smooth] if smooth else []
            if not verts or not faces:
                raise RuntimeError('Empty mesh '+ob.name)
            if not all(math.isfinite(c) for v in verts for c in v):
                raise RuntimeError('Non-finite mesh '+ob.name)
            mesh_ids[key]=len(mesh_defs)+1
            mesh_defs.append((verts,faces,smooth,hard_faces))
            face_count+=len(faces)
            vertex_count+=len(verts)
            ev.to_mesh_clear()
        m=ob.matrix_world
        basis=[(m[0][j],m[1][j],m[2][j]) for j in range(3)]
        translation=tuple(m.translation)
        material=ob.material_slots[0].material.name if ob.material_slots else 'Bronze_Frame'
        category=ob.users_collection[0].name
        instances.append((ob.name,mesh_ids[key],material,category,basis,translation))
    with path.open('w',encoding='utf-8-sig',newline='\n') as f:
        f.write('''/* NEW YEAR BUS SHELTER - standalone scene builder, metres.
   Uses embedded geometry only. No plugins, textures, external files or network.
   Adds objects without resetting, deleting or saving your existing scene.
   Physical materials with Standard fallback. Best-effort Max 2020+ support.
   MAXScript runtime has NOT been tested: 3ds Max is unavailable on build host.
   The companion preview was rendered from these same meshes in Blender.
   Run: Scripting > Run Script. Save as .max manually after checking the result.
*/
(
    local nyMade = #()
    local nyUnit = units.decodeValue "1m"
    local nyPrototypes = #()
    local nyMats = #()
    local nyLayers = #()
    local nyStamp = (timeStamp()) as string
    local nyOldNodeCount = objects.count
    fn nyProp obj prop value =
    (
        if isProperty obj prop do
            try (setProperty obj prop value)
            catch (format "Optional property skipped: % on %\\n" prop obj)
    )
    fn nyMaterial label rgb rough metallic trans emit =
    (
        local m = undefined
        try (m = PhysicalMaterial()) catch (m = standardMaterial())
        m.name = label
        if isProperty m #base_color then
        (
            nyProp m #base_color rgb
            nyProp m #base_weight 1.0
            nyProp m #roughness rough
            nyProp m #metalness metallic
            nyProp m #transparency trans
            nyProp m #trans_color (color 255 255 255)
            nyProp m #trans_ior 1.46
            nyProp m #thin_walled false
            if emit > 0 do
            (
                nyProp m #emission 1.0
                nyProp m #emit_color rgb
                nyProp m #emit_luminance (emit * 100.0)
            )
        )
        else
        (
            nyProp m #diffuse rgb
            nyProp m #specularLevel (25.0 + metallic * 55.0)
            nyProp m #glossiness ((1.0 - rough) * 75.0)
            nyProp m #opacity (if trans > 0.0 then 16.0 else 100.0)
            if emit > 0 do nyProp m #selfIllumAmount 80.0
            nyProp m #twoSided true
        )
        nyProp m #showInViewport true
        m
    )
    fn nyMake label vs fs mat isSmooth hardFaces unitScale =
    (
        for j = 1 to vs.count do vs[j] = vs[j] * unitScale
        local n = mesh name:label vertices:vs faces:fs
        n.material = mat
        for j = 1 to fs.count do setFaceSmoothGroup n j (if isSmooth then 1 else 0)
        for j in hardFaces do setFaceSmoothGroup n j 0
        update n
        n
    )
    disableSceneRedraw()
    undo "New Year Bus Shelter" on
    (
        try
        (
''')
        matindex={name:i+1 for i,name in enumerate(META)}
        for name,meta in META.items():
            f.write('            append nyMats (nyMaterial '+msquote('NY_'+name)+' (color '+
                    ' '.join(str(x) for x in meta['rgb'])+') '+
                    ' '.join(fmt(meta[x]) for x in ('rough','metal','transmission','emission'))+')\n')
        categories=sorted(set(inst[3] for inst in instances))
        catindex={name:i+1 for i,name in enumerate(categories)}
        for category in categories:
            f.write('            append nyLayers (LayerManager.newLayerFromName ('+msquote(category+'_')+' + nyStamp))\n')
        f.write('            local nyOb = undefined\n')
        for name,idx,material,category,basis,trans in instances:
            if mesh_defs[idx-1] is not None:
                vs,fs,smooth,hard_faces=mesh_defs[idx-1]
                f.write('            nyOb = nyMake '+msquote('NY_'+name)+' #(\n')
                f.write(',\n'.join('                '+point(v) for v in vs))
                f.write('\n            ) #(\n')
                f.write(',\n'.join('                ['+','.join(str(i) for i in face)+']' for face in fs))
                hard_array='#('+','.join(str(i) for i in hard_faces)+')'
                f.write('\n            ) nyMats['+str(matindex[material])+'] '+str(smooth).lower()+' '+hard_array+' nyUnit\n')
                f.write('            nyPrototypes['+str(idx)+'] = nyOb\n')
                mesh_defs[idx-1]=None
            else:
                f.write('            nyOb = instance nyPrototypes['+str(idx)+']\n')
                f.write('            nyOb.name = '+msquote('NY_'+name)+'\n')
                f.write('            nyOb.material = nyMats['+str(matindex[material])+']\n')
            f.write('            append nyMade nyOb\n')
            f.write('            nyOb.transform = matrix3 '+ ' '.join(point(b) for b in basis)+' ('+point(trans)+' * nyUnit)\n')
            f.write('            nyLayers['+str(catindex[category])+'].addNode nyOb\n')
        f.write('''            local nyCam = freeCamera name:("NY_Hero_Camera_" + nyStamp)
            append nyMade nyCam
''')
        m=camera.matrix_world
        basis=[(m[0][j],m[1][j],m[2][j]) for j in range(3)]
        f.write('            nyCam.transform = matrix3 '+' '.join(point(b) for b in basis)+' ('+point(camera.location)+' * nyUnit)\n')
        f.write('            nyCam.fov = '+fmt(math.degrees(2*math.atan(camdata.sensor_width/(2*camdata.lens))))+'\n')
        f.write('''            nyProp nyCam #nearclip (0.03 * nyUnit)
            nyProp nyCam #farclip (200.0 * nyUnit)
            local nyLight = undefined
''')
        for label,loc,rgb,mult in [
                ('Winter_Key',(-4,-6,9),(255,228,199),1.0),
                ('Winter_Fill',(5,-2,7),(166,204,255),.45),
                ('Winter_Rim',(0,5,8),(219,232,255),.8),
                ('Face_Bounce',(-1,-5,4),(255,202,157),.18)]:
            f.write('            nyLight = omniLight name:'+msquote('NY_'+label)+' pos:('+point(loc)+' * nyUnit) rgb:(color '+' '.join(map(str,rgb))+') multiplier:'+fmt(mult)+'\n')
            f.write('            append nyMade nyLight\n')
            f.write('            nyProp nyLight #castShadows true\n')
        f.write('''            if nyOldNodeCount == 0 do
            (
                renderWidth = 1400
                renderHeight = 1400
                backgroundColor = color 177 196 211
                ambientColor = color 28 34 42
            )
            try (viewport.setCamera nyCam) catch ()
            clearSelection()
            enableSceneRedraw()
            redrawViews()
            format "New Year Bus Shelter: % nodes created. Save your scene as .max manually.\\n" nyMade.count
            messageBox "Holiday bus shelter created.\\n\\nThe scene is editable and grouped in NY_ layers.\\nSave As .max to keep it.\\n\\nThe PNG preview uses the same geometry, rendered in Blender.\\nLighting/material appearance in Max depends on your renderer and exposure." title:"New Year Bus Shelter"
        )
        catch
        (
            local nyError = getCurrentException()
            for n in nyMade where isValidNode n do try (delete n) catch ()
            enableSceneRedraw()
            redrawViews()
            messageBox ("Scene creation failed. Existing objects were not deleted.\\n\\n" + nyError) title:"New Year Bus Shelter - error"
            format "New Year Bus Shelter ERROR: %\\n" nyError
        )
    )
)
''')
    report=dict(objects=len(instances),unique_meshes=len(mesh_ids),
                unique_vertices=vertex_count,unique_triangles=face_count,
                materials=len(META),ms_bytes=path.stat().st_size,
                max_runtime_tested=False,geometry_source='Same Blender scene as preview',
                width_m=5.02,roof_height_m=2.99,max_height_m=4.82)
    (OUT/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('EXPORT_REPORT',json.dumps(report),flush=True)

scene=bpy.context.scene
scene.render.engine='CYCLES'
scene.cycles.samples=192
scene.cycles.adaptive_threshold=.04
scene.cycles.use_denoising=False
scene.cycles.max_bounces=8
scene.cycles.transmission_bounces=8
scene.render.resolution_x=1400
scene.render.resolution_y=1400
scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
scene.render.filepath=str(OUT/'preview.png')
scene.view_settings.view_transform='AgX'
scene.view_settings.look='AgX - Medium High Contrast'
scene.render.film_transparent=False
scene.render.threads_mode='FIXED'
scene.render.threads=8

# Light halation is subtle; it is not baked into the actual geometry.
scene.use_nodes=True
nodes=scene.node_tree.nodes
nodes.clear()
rl=nodes.new('CompositorNodeRLayers')
glare=nodes.new('CompositorNodeGlare')
glare.glare_type='FOG_GLOW'
glare.quality='HIGH'
glare.threshold=2.0
glare.mix=-.94
comp=nodes.new('CompositorNodeComposite')
scene.node_tree.links.new(rl.outputs['Image'],glare.inputs['Image'])
scene.node_tree.links.new(glare.outputs['Image'],comp.inputs['Image'])

bpy.context.view_layer.update()
for obj in bpy.context.scene.objects:
    if 'bow knot' in obj.name:
        dims=tuple(obj.dimensions)
        if not all(abs(a-b)<.002 for a,b in zip(dims,(.11,.08,.07))):
            # Z rotation changes the world bounding box, but preserves matrix scale.
            scales=tuple(obj.matrix_world.to_scale())
            if not all(abs(a-b)<.0001 for a,b in zip(scales,(.055,.04,.035))):
                raise RuntimeError('Gift transform lost: '+obj.name)
export_maxscript()
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'Holiday_BusStop.blend'))
bpy.ops.render.render(write_still=True)
print('BUILD_AND_RENDER_COMPLETE',flush=True)
